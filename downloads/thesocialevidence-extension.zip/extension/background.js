// The Social Evidence — background service worker.
//
// Proxies API calls for the content script. Requests from here can't be
// blocked by a page's Content-Security-Policy, unlike fetches made directly
// from the content script on strict sites.

const baseUrl = "https://the-social-evidence-api.appspot.com";

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== "tse-fetch") return;
  fetch(baseUrl + msg.path, msg.init)
    .then(async (r) => sendResponse({ ok: r.ok, status: r.status, body: await r.text() }))
    .catch((err) => sendResponse({ ok: false, status: 0, error: String(err) }));
  return true; // keep the message channel open for the async response
});
