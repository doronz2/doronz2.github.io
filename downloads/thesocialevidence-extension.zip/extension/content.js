// The Social Evidence — content script.
//
// Quotes are anchored by their exact text plus surrounding context (not DOM
// node paths), so highlights survive page changes and work across users.

const baseUrl = "https://thesocialevidence-extension.appspot.com";
// For local development: const baseUrl = "http://localhost:8080";

const CONTEXT_LEN = 60;
let quotesById = {};

// ---------------------------------------------------------------------------
// Selection button
// ---------------------------------------------------------------------------

const selectButton = document.createElement("button");
selectButton.className = "tse-select-button";
selectButton.textContent = "💬 Comment";
selectButton.style.display = "none";
document.documentElement.appendChild(selectButton);

document.addEventListener("mouseup", (e) => {
  if (e.target === selectButton) return;
  // Let the browser finish updating the selection first.
  setTimeout(() => {
    const sel = window.getSelection();
    if (!sel || sel.isCollapsed || !sel.toString().trim()) {
      selectButton.style.display = "none";
      return;
    }
    const rect = sel.getRangeAt(0).getBoundingClientRect();
    selectButton.style.display = "block";
    selectButton.style.top = window.scrollY + rect.bottom + 8 + "px";
    selectButton.style.left =
      window.scrollX + Math.max(8, rect.left + rect.width / 2 - 50) + "px";
  }, 0);
});

selectButton.addEventListener("mousedown", (e) => {
  // Prevent the click from collapsing the selection before we read it.
  e.preventDefault();
  e.stopPropagation();
  onCommentClicked();
});

// ---------------------------------------------------------------------------
// Saving a new quote
// ---------------------------------------------------------------------------

async function getAuthor() {
  const stored = await chrome.storage.local.get("author");
  if (stored.author) return stored.author;
  const name = (prompt("Your name (shown next to your comments):") || "").trim();
  if (name) await chrome.storage.local.set({ author: name });
  return name || "Anonymous";
}

async function onCommentClicked() {
  const sel = window.getSelection();
  if (!sel || sel.isCollapsed) return;
  const range = sel.getRangeAt(0);
  const anchor = buildAnchor(range);
  if (!anchor) {
    alert("Sorry, this selection can't be saved. Try selecting plain text.");
    return;
  }

  const author = await getAuthor();
  const comment = (prompt("Your comment:") || "").trim();
  if (!comment) return;

  selectButton.style.display = "none";

  try {
    const response = await fetch(baseUrl + "/api/quotes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        url: location.href,
        text: anchor.text,
        prefix: anchor.prefix,
        suffix: anchor.suffix,
        author,
        comment,
      }),
    });
    if (!response.ok) throw new Error("HTTP " + response.status);
    const quote = await response.json();
    quotesById[quote._id] = quote;
    highlightQuote(quote);
    sel.removeAllRanges();
  } catch (err) {
    console.error("The Social Evidence: save failed", err);
    alert("Could not save your comment — the server may be unreachable.");
  }
}

// Build a text anchor {text, prefix, suffix} from a Range.
function buildAnchor(range) {
  const text = range.toString();
  if (!text.trim()) return null;
  const body = getBodyText();
  // Locate the selection inside the page text to grab surrounding context.
  const positions = findAll(body.text, text);
  let pos = positions.length ? positions[0] : -1;
  if (positions.length > 1) {
    // Disambiguate using the range start point.
    const rangeStart = textOffsetOfPoint(body, range.startContainer, range.startOffset);
    pos = positions.reduce((best, p) =>
      Math.abs(p - rangeStart) < Math.abs(best - rangeStart) ? p : best
    );
  }
  if (pos === -1) return { text, prefix: "", suffix: "" };
  return {
    text,
    prefix: body.text.slice(Math.max(0, pos - CONTEXT_LEN), pos),
    suffix: body.text.slice(pos + text.length, pos + text.length + CONTEXT_LEN),
  };
}

// ---------------------------------------------------------------------------
// Loading and restoring highlights
// ---------------------------------------------------------------------------

async function loadQuotes() {
  try {
    const response = await fetch(
      baseUrl + "/api/quotes?url=" + encodeURIComponent(location.href)
    );
    if (!response.ok) throw new Error("HTTP " + response.status);
    const quotes = await response.json();
    for (const quote of quotes) {
      quotesById[quote._id] = quote;
      try {
        highlightQuote(quote);
      } catch (err) {
        console.warn("The Social Evidence: could not highlight quote", quote._id, err);
      }
    }
  } catch (err) {
    console.warn("The Social Evidence: could not load comments", err);
  }
}

function highlightQuote(quote) {
  if (document.querySelector(`[data-tse-id="${quote._id}"]`)) return; // already shown
  const range = findRangeForAnchor(quote);
  if (!range) return;
  for (const node of textNodesInRange(range)) {
    const span = document.createElement("span");
    span.className = "tse-highlight";
    span.dataset.tseId = quote._id;
    span.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      openPanel(quote._id);
    });
    node.parentNode.insertBefore(span, node);
    span.appendChild(node);
  }
}

// --- text <-> DOM mapping helpers ---

function isVisibleTextNode(node) {
  const p = node.parentElement;
  if (!p) return false;
  const tag = p.tagName;
  if (tag === "SCRIPT" || tag === "STYLE" || tag === "NOSCRIPT") return false;
  if (p.closest(".tse-panel, .tse-select-button")) return false;
  return true;
}

// Concatenated text of all visible text nodes + per-node offsets.
function getBodyText() {
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  const nodes = [];
  const starts = [];
  let text = "";
  let node;
  while ((node = walker.nextNode())) {
    if (!isVisibleTextNode(node)) continue;
    nodes.push(node);
    starts.push(text.length);
    text += node.nodeValue;
  }
  return { text, nodes, starts };
}

function findAll(haystack, needle) {
  const out = [];
  let i = haystack.indexOf(needle);
  while (i !== -1) {
    out.push(i);
    i = haystack.indexOf(needle, i + 1);
  }
  return out;
}

function textOffsetOfPoint(body, container, offset) {
  if (container.nodeType === Node.TEXT_NODE) {
    const idx = body.nodes.indexOf(container);
    if (idx !== -1) return body.starts[idx] + offset;
  }
  return 0;
}

// Convert a global text offset back into a (textNode, localOffset) point.
function pointAtOffset(body, offset) {
  for (let i = 0; i < body.nodes.length; i++) {
    const end = body.starts[i] + body.nodes[i].nodeValue.length;
    if (offset < end || i === body.nodes.length - 1) {
      return { node: body.nodes[i], offset: Math.max(0, offset - body.starts[i]) };
    }
  }
  return null;
}

function findRangeForAnchor(quote) {
  const body = getBodyText();
  const positions = findAll(body.text, quote.text);
  if (positions.length === 0) return null;
  let pos = positions[0];
  if (positions.length > 1 && (quote.prefix || quote.suffix)) {
    // Pick the occurrence whose surroundings best match the stored context.
    let bestScore = -1;
    for (const p of positions) {
      const pre = body.text.slice(Math.max(0, p - CONTEXT_LEN), p);
      const suf = body.text.slice(p + quote.text.length, p + quote.text.length + CONTEXT_LEN);
      const score =
        commonSuffixLen(pre, quote.prefix || "") + commonPrefixLen(suf, quote.suffix || "");
      if (score > bestScore) {
        bestScore = score;
        pos = p;
      }
    }
  }
  const start = pointAtOffset(body, pos);
  const end = pointAtOffset(body, pos + quote.text.length);
  if (!start || !end) return null;
  const range = document.createRange();
  try {
    range.setStart(start.node, Math.min(start.offset, start.node.nodeValue.length));
    range.setEnd(end.node, Math.min(end.offset, end.node.nodeValue.length));
    return range;
  } catch {
    return null;
  }
}

function commonPrefixLen(a, b) {
  let i = 0;
  while (i < a.length && i < b.length && a[i] === b[i]) i++;
  return i;
}
function commonSuffixLen(a, b) {
  let i = 0;
  while (i < a.length && i < b.length && a[a.length - 1 - i] === b[b.length - 1 - i]) i++;
  return i;
}

// All text nodes covered by a range, with boundary nodes split so each
// returned node is fully inside the range (safe to wrap individually —
// unlike range.surroundContents, this works across element boundaries).
function textNodesInRange(range) {
  // Capture boundaries up-front: splitText() mutates live Range offsets,
  // so we must not read from `range` after splitting.
  let startNode = range.startContainer;
  let endNode = range.endContainer;
  const startOffset = range.startOffset;
  let endOffset = range.endOffset;

  if (startNode.nodeType === Node.TEXT_NODE && startOffset > 0) {
    const newStart = startNode.splitText(startOffset);
    if (startNode === endNode) {
      endNode = newStart;
      endOffset -= startOffset;
    }
    startNode = newStart;
  }
  if (endNode.nodeType === Node.TEXT_NODE && endOffset < endNode.nodeValue.length) {
    endNode.splitText(endOffset);
  }

  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  const nodes = [];
  let inRange = false;
  let node;
  while ((node = walker.nextNode())) {
    if (node === startNode) inRange = true;
    if (inRange && isVisibleTextNode(node) && node.nodeValue.length > 0) nodes.push(node);
    if (node === endNode) break;
  }
  return nodes;
}

// ---------------------------------------------------------------------------
// Comments panel
// ---------------------------------------------------------------------------

let panel = null;

function closePanel() {
  if (panel) {
    panel.remove();
    panel = null;
  }
}

async function openPanel(quoteId) {
  closePanel();

  // Refresh from the server so bot comments and other users' replies show up.
  try {
    const response = await fetch(
      baseUrl + "/api/quotes?url=" + encodeURIComponent(location.href)
    );
    if (response.ok) {
      for (const q of await response.json()) quotesById[q._id] = q;
    }
  } catch {
    /* offline — show what we have */
  }

  const quote = quotesById[quoteId];
  if (!quote) return;

  panel = document.createElement("div");
  panel.className = "tse-panel";

  const header = document.createElement("div");
  header.className = "tse-panel-header";
  header.textContent = "The Social Evidence";
  const close = document.createElement("button");
  close.className = "tse-panel-close";
  close.textContent = "✕";
  close.addEventListener("click", closePanel);
  header.appendChild(close);
  panel.appendChild(header);

  const quoteEl = document.createElement("blockquote");
  quoteEl.className = "tse-panel-quote";
  quoteEl.textContent = quote.text;
  panel.appendChild(quoteEl);

  const list = document.createElement("div");
  list.className = "tse-panel-comments";
  for (const c of quote.comments || []) {
    const item = document.createElement("div");
    item.className = "tse-comment" + (c.isBot ? " tse-comment-bot" : "");
    const meta = document.createElement("div");
    meta.className = "tse-comment-meta";
    meta.textContent =
      (c.author || "Anonymous") +
      (c.createdAt ? " · " + new Date(c.createdAt).toLocaleDateString() : "");
    const body = document.createElement("div");
    body.className = "tse-comment-text";
    body.textContent = c.text;
    item.appendChild(meta);
    item.appendChild(body);
    list.appendChild(item);
  }
  panel.appendChild(list);

  const form = document.createElement("div");
  form.className = "tse-panel-form";
  const input = document.createElement("textarea");
  input.className = "tse-panel-input";
  input.placeholder = "Add a comment…";
  const submit = document.createElement("button");
  submit.className = "tse-panel-submit";
  submit.textContent = "Reply";
  submit.addEventListener("click", async () => {
    const text = input.value.trim();
    if (!text) return;
    submit.disabled = true;
    try {
      const author = await getAuthor();
      const response = await fetch(baseUrl + "/api/quotes/" + quoteId + "/comments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ author, text }),
      });
      if (!response.ok) throw new Error("HTTP " + response.status);
      quotesById[quoteId] = await response.json();
      openPanel(quoteId); // re-render with the new comment
    } catch (err) {
      console.error("The Social Evidence: reply failed", err);
      alert("Could not post your reply — the server may be unreachable.");
      submit.disabled = false;
    }
  });
  form.appendChild(input);
  form.appendChild(submit);
  panel.appendChild(form);

  document.documentElement.appendChild(panel);
}

// ---------------------------------------------------------------------------
// Boot: load once, then retry a couple of times for late-rendering pages.
// ---------------------------------------------------------------------------

loadQuotes();
setTimeout(loadQuotes, 3000);
setTimeout(loadQuotes, 8000);
